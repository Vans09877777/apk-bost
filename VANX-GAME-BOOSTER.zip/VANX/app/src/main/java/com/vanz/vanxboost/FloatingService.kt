package com.vanz.vanxboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.abs

class CrosshairView(c: Context) : View(c) {
    var shape = 1
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00FF66"); style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00FF66"); style = Paint.Style.FILL }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = 14f * d; val g = 5f * d
        when (shape) {
            1 -> {
                c.drawLine(cx - r, cy, cx - g, cy, line); c.drawLine(cx + g, cy, cx + r, cy, line)
                c.drawLine(cx, cy - r, cx, cy - g, line); c.drawLine(cx, cy + g, cx, cy + r, line)
            }
            2 -> c.drawCircle(cx, cy, 3f * d, dot)
            3 -> { c.drawCircle(cx, cy, r * 0.8f, line); c.drawCircle(cx, cy, 2f * d, dot) }
        }
    }
}

/** Floating panel di samping (bisa digeser): mode, Hz layar, crosshair, screenshot, rekam layar. */
class FloatingService : Service() {
    companion object {
        @Volatile var instance: FloatingService? = null
        val running = MutableStateFlow(false)
        fun start(c: Context) { c.startForegroundService(Intent(c, FloatingService::class.java)) }
        fun stop(c: Context) { c.stopService(Intent(c, FloatingService::class.java)) }
    }

    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var menu: LinearLayout? = null
    private var hud: TextView? = null
    private var cross: CrosshairView? = null
    private var modeBtn: TextView? = null
    private var recBtn: TextView? = null
    private var hudOn = true
    private var shown = true
    private var hz = 0
    private var frames = 0
    private var t0 = 0L
    private var d = 1f
    private val modes = listOf("BALANCED", "PERFORMANCE", "BATTERY")
    private val red = Color.parseColor("#FF2D4A")

    private val tick = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (t0 == 0L) t0 = ns
            frames++
            if (ns - t0 >= 1_000_000_000L) { hz = Math.round(frames * 1e9f / (ns - t0)); frames = 0; t0 = ns }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val hudLoop = object : Runnable {
        override fun run() {
            val s = Sys.snap(this@FloatingService)
            hud?.text = "%d Hz  %.0f°C  %d%%  RAM %.1fG".format(hz, s.batTempC, s.batPct, s.ramAvailMb / 1024f)
            recBtn?.text = if (CaptureService.recording.value) "⏹\nSTOP" else "⏺\nREC"
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this; running.value = true
        d = resources.displayMetrics.density
        store = Store(this)
        wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vanx_float", "Floating panel", NotificationManager.IMPORTANCE_MIN))
        startForeground(4, Notification.Builder(this, "vanx_float").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("VANX floating panel aktif").build())
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        buildHud(); buildCross(); buildPanel()
        Choreographer.getInstance().postFrameCallback(tick)
        handler.post(hudLoop)
    }

    private fun params(touch: Boolean, w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or (if (touch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    )

    private fun rounded(fill: Int, stroke: Int, r: Float) = GradientDrawable().apply { setColor(fill); setStroke(2, stroke); cornerRadius = r }

    private fun buildHud() {
        val t = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.MONOSPACE
            setPadding(16, 6, 16, 6); background = rounded(Color.argb(150, 0, 0, 0), red, 12f)
        }
        wm.addView(t, params(false, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 24
        })
        hud = t
    }

    private fun buildCross() {
        val v = CrosshairView(this).apply { shape = store.xhair }
        val sz = (96 * d).toInt()
        wm.addView(v, params(false, sz, sz).apply { gravity = Gravity.CENTER })
        cross = v
        applyVis()
    }

    private fun modeLabel(m: String) = "⚡\n" + when (m) { "PERFORMANCE" -> "PERF"; "BATTERY" -> "BATT"; else -> "BAL" }

    private fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 9f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.argb(210, 20, 20, 28), red, 12f * d)
        layoutParams = LinearLayout.LayoutParams((46 * d).toInt(), (46 * d).toInt()).apply { topMargin = (6 * d).toInt() }
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val handle = TextView(this).apply {
            text = "V"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#B00020"), red)).apply { shape = GradientDrawable.OVAL }
            layoutParams = LinearLayout.LayoutParams((46 * d).toInt(), (46 * d).toInt())
        }
        modeBtn = btn(modeLabel(store.profile("_global").mode)) { cycleMode() }
        recBtn = btn("⏺\nREC") {
            if (CaptureService.recording.value) CaptureService.stop(this) else capture("REC")
        }
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(modeBtn)
            addView(btn("📶\nHz") { hudOn = !hudOn; applyVis() })
            addView(btn("🎯\nXHAIR") { cycleCross() })
            addView(btn("📷\nSHOT") { capture("SHOT") })
            addView(recBtn)
            addView(btn("✕\nTUTUP") { stopSelf() })
        }
        menu = m
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            val pad = (4 * d).toInt(); setPadding(pad, pad, pad, pad)
            background = rounded(Color.argb(120, 0, 0, 0), Color.TRANSPARENT, 30f * d)
            addView(handle); addView(m)
        }
        panel = p
        lp = params(true, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 0; y = (200 * d).toInt()
        }
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx; val dy = e.rawY - ty
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt(); wm.updateViewLayout(p, lp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) toggleMenu(null) else {
                        val dm = resources.displayMetrics
                        lp.x = if (lp.x + p.width / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - p.width
                        lp.y = lp.y.coerceAtMost(dm.heightPixels - p.height).coerceAtLeast(0)
                        wm.updateViewLayout(p, lp)
                    }
                }
                return true
            }
        })
        wm.addView(p, lp)
    }

    private fun toggleMenu(open: Boolean?) {
        val m = menu ?: return
        val want = open ?: (m.visibility == View.GONE)
        m.visibility = if (want) View.VISIBLE else View.GONE
        if (want) {
            val hp = resources.displayMetrics.heightPixels
            lp.y = lp.y.coerceAtMost((hp - (390 * d).toInt()).coerceAtLeast(0))
        }
        panel?.let { wm.updateViewLayout(it, lp) }
    }

    private fun cycleMode() {
        val cur = store.profile("_global")
        val n = modes[(modes.indexOf(cur.mode) + 1) % modes.size]
        store.saveProfile("_global", cur.copy(mode = n))
        GameSessionService.state.value?.let { s -> store.saveProfile(s.pkg, store.profile(s.pkg).copy(mode = n)) }
        if (n == "PERFORMANCE") store.minAnim = true
        modeBtn?.text = modeLabel(n)
        Toast.makeText(this, "Mode: $n", Toast.LENGTH_SHORT).show()
    }

    private fun cycleCross() {
        val c = cross ?: return
        c.shape = (c.shape + 1) % 4
        store.xhair = c.shape
        c.invalidate(); applyVis()
    }

    private fun capture(mode: String) {
        toggleMenu(false)
        startActivity(Intent(this, CaptureActivity::class.java).putExtra("mode", mode).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun setShown(b: Boolean) { handler.post { shown = b; applyVis() } }

    private fun applyVis() {
        panel?.visibility = if (shown) View.VISIBLE else View.INVISIBLE
        hud?.visibility = if (shown && hudOn) View.VISIBLE else View.INVISIBLE
        cross?.visibility = if (shown && (cross?.shape ?: 0) != 0) View.VISIBLE else View.INVISIBLE
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(tick)
        listOf(panel, hud, cross).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        panel = null; hud = null; cross = null
        instance = null; running.value = false
        super.onDestroy()
    }
}

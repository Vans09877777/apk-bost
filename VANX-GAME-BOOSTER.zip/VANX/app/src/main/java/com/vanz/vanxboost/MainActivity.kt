package com.vanz.vanxboost

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Neon = Color(0xFFFF2D4A) // aksen merah ala ROG
val Purple = Color(0xFF00E5FF) // aksen sekunder cyan
val Bg = Color(0xFF000000)
val Dim = Color(0xFF9AA0B5)
private val GlassShape = CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp)
private val GlassFill = Brush.linearGradient(listOf(Color(0x22FFFFFF), Color(0x0AFFFFFF)))
private val GlassStroke = Brush.linearGradient(listOf(Neon.copy(alpha = .5f), Purple.copy(alpha = .5f)))
private val GaugeBrush = Brush.sweepGradient(listOf(Purple, Neon, Purple))
private val RingBrush = Brush.sweepGradient(listOf(Color.Transparent, Neon, Purple))
private val VanxColors = darkColorScheme(
    primary = Neon, secondary = Purple, background = Bg, surface = Color(0xFF0B0B14),
    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme(colorScheme = VanxColors) { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    LaunchedEffect(Unit) { AppCache.get(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var launching by remember { mutableStateOf<AppItem?>(null) }
    val tabs = listOf(
        "Home" to Icons.Default.Home, "Games" to Icons.Default.PlayArrow, "Booster" to Icons.Default.Build,
        "Monitor" to Icons.Default.Info, "Settings" to Icons.Default.Settings
    )
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A060C), Bg, Bg)))) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF07070D)) {
                    tabs.forEachIndexed { i, (n, ic) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(ic, n) }, label = { Text(n, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Neon, selectedTextColor = Neon, indicatorColor = Color(0x33FF2D4A), unselectedIconColor = Dim, unselectedTextColor = Dim))
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> Home(store) { launching = it }
                    1 -> Games(store) { launching = it }
                    2 -> Booster(store)
                    3 -> Monitor(store)
                    else -> SettingsScreen()
                }
            }
        }
        launching?.let { LaunchScreen(it, store) { launching = null } }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = GlassShape
    var m = modifier.fillMaxWidth().clip(shape)
        .background(GlassFill)
        .border(1.dp, GlassStroke, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(14.dp), content = content)
}

@Composable
fun Stat(title: String, value: String, sub: String, m: Modifier = Modifier) = Glass(m) {
    Text(title, color = Dim, fontSize = 12.sp)
    Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text(sub, color = Neon, fontSize = 11.sp)
}

@Composable
fun rememberSnap(ms: Long): State<Snap?> {
    val c = LocalContext.current
    return produceState<Snap?>(null, ms) {
        while (true) { value = withContext(Dispatchers.IO) { Sys.snap(c) }; delay(ms) }
    }
}

@Composable
fun Home(store: Store, onLaunch: (AppItem) -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(store.profile("_global").mode) }
    val s by rememberSnap(pollMs(mode))
    val sess by GameSessionService.state.collectAsState()
    val floating by FloatingService.running.collectAsState()
    var res by remember { mutableStateOf<BoostResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var games by remember { mutableStateOf(listOf<AppItem>()) }
    val elapsed by produceState(0L) {
        while (true) { value = GameSessionService.state.value?.let { (SystemClock.elapsedRealtime() - it.startMs) / 1000 } ?: 0L; delay(1000) }
    }
    LaunchedEffect(Unit) {
        val lib = store.library()
        games = AppCache.get(c).filter { it.pkg in lib }
    }
    fun boost() {
        if (busy) return
        busy = true
        scope.launch { res = runBoost(c, store.profile("_global"), null, store); busy = false }
    }
    val x = s
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("VANX", color = Neon, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                Text("GAME BOOSTER", color = Color.White, fontSize = 11.sp, letterSpacing = 3.sp)
            }
            if (x != null) Text("%.0f°C".format(x.batTempC), color = if (x.batTempC >= 42) Neon else Purple, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        val pct = if (x == null) 0f else x.ramUsedMb.toFloat() / x.ramTotalMb.coerceAtLeast(1)
        Box(Modifier.fillMaxWidth(), Alignment.Center) {
            Gauge(pct, "${(pct * 100).toInt()}%", if (busy) "MENGOPTIMALKAN" else "RAM TERPAKAI") { boost() }
        }
        GameButton(if (busy) "MENGANALISIS..." else "BOOST", Modifier.fillMaxWidth(), !busy) { boost() }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("BALANCED" to "BALANCED", "PERFORMANCE" to "PERFORM", "BATTERY" to "BATTERY").forEach { (k, l) ->
                GameChip(l, mode == k, Modifier.weight(1f)) {
                    mode = k
                    store.saveProfile("_global", store.profile("_global").copy(mode = k))
                    if (k == "PERFORMANCE") store.minAnim = true
                }
            }
        }
        sess?.let { z ->
            Glass {
                Text("SESI AKTIF: ${z.label}", color = Color.White, fontWeight = FontWeight.Bold)
                Text("%d:%02d:%02d".format(elapsed / 3600, elapsed % 3600 / 60, elapsed % 60), color = Purple, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { GameSessionService.stop(c) }) { Text("Hentikan sesi") }
            }
        }
        Glass {
            SwitchRow("Floating panel (mode, Hz, crosshair, screenshot, rekam)", floating) { on ->
                if (!on) FloatingService.stop(c)
                else if (Settings.canDrawOverlays(c)) FloatingService.start(c)
                else c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
            }
        }
        if (x != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("SUHU", "%.1f°C".format(x.batTempC), "Termal: ${Sys.thermalLabel(x.thermal)}", Modifier.weight(1f))
                Stat("BATERAI", "${x.batPct}%", if (x.charging) "Mengisi daya" else "Tidak mengisi", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("RAM BEBAS", "${x.ramAvailMb} MB", "dari ${x.ramTotalMb} MB", Modifier.weight(1f))
                Stat("JARINGAN", x.net, "Storage %.0f / %.0f GB".format(x.storUsedGb, x.storTotalGb), Modifier.weight(1f))
            }
        }
        res?.let { r -> Glass { r.lines.forEach { Text("• $it", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) } } }
        Text("GAME", color = Neon, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        if (games.isEmpty()) Text("Belum ada game di library. Tambahkan lewat tab Games.", color = Dim, fontSize = 12.sp)
        else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(games, key = { it.pkg }) { g ->
                Column(Modifier.width(64.dp).clickable { onLaunch(g) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    AppIcon(g.pkg, 56.dp)
                    Text(g.label, color = Color.White, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun Gauge(pct: Float, label: String, sub: String, onClick: () -> Unit) {
    val anim by animateFloatAsState(pct.coerceIn(0f, 1f), tween(800), label = "gauge")
    Box(
        Modifier.size(240.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().padding(14.dp)) {
            val st = Stroke(width = 22.dp.toPx(), cap = StrokeCap.Round)
            drawArc(color = Color(0xFF1B1B24), startAngle = 135f, sweepAngle = 270f, useCenter = false, style = st)
            drawArc(brush = GaugeBrush, startAngle = 135f, sweepAngle = 270f * anim, useCenter = false, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Black)
            Text(sub, color = Neon, fontSize = 11.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun GameButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp)
    Box(
        modifier.clip(shape).background(Brush.horizontalGradient(listOf(Color(0xFFB00020), Neon)))
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 16.dp),
        Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 3.sp, fontSize = 16.sp) }
}

@Composable
fun GameChip(text: String, sel: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)
    Box(
        modifier.clip(shape).background(if (sel) Neon else Color(0x22FFFFFF))
            .border(1.dp, if (sel) Neon else Color(0x44FFFFFF), shape)
            .clickable(onClick = onClick).padding(vertical = 10.dp),
        Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val c = LocalContext.current
    val bmp by produceState<ImageBitmap?>(AppCache.icons[pkg], pkg) {
        if (value == null) value = withContext(Dispatchers.IO) {
            runCatching { c.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }
                .getOrNull()?.also { AppCache.icons[pkg] = it }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    else Box(Modifier.size(size).background(Color(0x22FFFFFF), RoundedCornerShape(10.dp)))
}

@Composable
fun SwitchRow(label: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
        Switch(v, on)
    }
}

@Composable
fun ProfileForm(p: Profile, showGfx: Boolean = false, onChange: (Profile) -> Unit) {
    Column {
        Text("Mode performa", color = Neon, fontWeight = FontWeight.Bold)
        listOf(
            "BALANCED" to "Balanced: monitor tiap 2 dtk, seimbang",
            "PERFORMANCE" to "Performance: monitor tiap 5 dtk, animasi minim",
            "BATTERY" to "Battery Saver: monitor tiap 10 dtk, paling hemat"
        ).forEach { (k, l) ->
            Row(Modifier.fillMaxWidth().clickable { onChange(p.copy(mode = k)) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(p.mode == k, { onChange(p.copy(mode = k)) })
                Text(l, fontSize = 12.sp, color = Color.White)
            }
        }
        if (showGfx) {
            Text("Preset grafik", color = Neon, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            listOf("NORMAL" to "Normal", "HEMAT" to "Hemat (grafik sedang)", "BURIK" to "Burik (grafik terendah, FPS maksimal)").forEach { (k, l) ->
                Row(Modifier.fillMaxWidth().clickable { onChange(p.copy(gfx = k)) }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(p.gfx == k, { onChange(p.copy(gfx = k)) })
                    Text(l, fontSize = 12.sp, color = Color.White)
                }
            }
        }
        SwitchRow("Jangan Ganggu saat bermain", p.dnd) { onChange(p.copy(dnd = it)) }
        SwitchRow("Bersihkan proses latar", p.clean) { onChange(p.copy(clean = it)) }
        SwitchRow("Floating panel saat bermain", p.overlay) { onChange(p.copy(overlay = it)) }
        Text("Peringatan panas di ${p.warnC}°C", color = Color.White, fontSize = 13.sp)
        Slider(p.warnC.toFloat(), { onChange(p.copy(warnC = it.toInt())) }, valueRange = 36f..50f)
    }
}

@Composable
fun ProfileDialog(title: String, init: Profile, onSave: (Profile) -> Unit, onDismiss: () -> Unit) {
    var p by remember { mutableStateOf(init) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color(0xFF10101C),
        title = { Text("Profil: $title") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { ProfileForm(p, true) { p = it } } },
        confirmButton = { TextButton({ onSave(p) }) { Text("Simpan") } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } }
    )
}

@Composable
fun AppRow(a: AppItem, inLib: Boolean, onOpen: () -> Unit, onProfile: () -> Unit, onToggle: () -> Unit) {
    Glass(Modifier.padding(vertical = 4.dp), onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(a.pkg)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(a.label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(a.pkg, color = Dim, fontSize = 10.sp, maxLines = 1)
            }
            if (inLib) {
                IconButton(onProfile) { Icon(Icons.Default.Settings, "Profil", tint = Neon) }
                IconButton(onToggle) { Icon(Icons.Default.Delete, "Hapus", tint = Purple) }
            } else IconButton(onToggle) { Icon(Icons.Default.Add, "Tambah", tint = Neon) }
        }
    }
}

@Composable
fun Header(t: String) = Text(t, color = Neon, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))

@Composable
fun Games(store: Store, onLaunch: (AppItem) -> Unit) {
    val c = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(AppCache.apps) }
    var lib by remember { mutableStateOf(store.library()) }
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<AppItem?>(null) }
    LaunchedEffect(Unit) { apps = AppCache.get(c) }
    fun toggle(pkg: String) { lib = if (pkg in lib) lib - pkg else lib + pkg; store.setLibrary(lib) }
    val f = (apps ?: emptyList()).filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 12.dp), label = { Text("Cari aplikasi") }, singleLine = true)
        TabRow(tab, containerColor = Color.Transparent, contentColor = Neon) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Games") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Apps") })
        }
        if (apps == null) Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Neon) }
        else LazyColumn(Modifier.fillMaxSize()) {
            if (tab == 0) {
                val mine = f.filter { it.pkg in lib }
                val det = f.filter { it.isGame && it.pkg !in lib }
                item(key = "h1") { Header("Game Library (${mine.size})") }
                if (mine.isEmpty()) item(key = "e1") { Text("Kosong. Tambahkan dari daftar terdeteksi atau tab Apps.", color = Dim, fontSize = 12.sp) }
                items(mine, key = { "m_" + it.pkg }) { a -> AppRow(a, true, { onLaunch(a) }, { editing = a }, { toggle(a.pkg) }) }
                item(key = "h2") { Header("Game terdeteksi") }
                items(det, key = { "d_" + it.pkg }) { a -> AppRow(a, false, { onLaunch(a) }, {}, { toggle(a.pkg) }) }
            } else {
                items(f.filter { it.pkg !in lib }, key = { "a_" + it.pkg }) { a -> AppRow(a, false, { onLaunch(a) }, {}, { toggle(a.pkg) }) }
            }
        }
    }
    editing?.let { a ->
        ProfileDialog(a.label, store.profile(a.pkg), { store.saveProfile(a.pkg, it); editing = null }, { editing = null })
    }
}

@Composable
fun Booster(store: Store) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var p by remember { mutableStateOf(store.profile("_global")) }
    var res by remember { mutableStateOf<BoostResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var minAnim by remember { mutableStateOf(store.minAnim) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Smart Booster", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Button(
            onClick = { busy = true; scope.launch { res = runBoost(c, p, null, store); minAnim = store.minAnim; busy = false } },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text(if (busy) "Menganalisis..." else "BOOST", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        res?.let { r -> Glass { r.lines.forEach { Text("• $it", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) } } }
        Glass {
            ProfileForm(p) { p = it; store.saveProfile("_global", it) }
            SwitchRow("Mode minim animasi", minAnim) { minAnim = it; store.minAnim = it }
        }
    }
}

@Composable
fun rememberOwnFps(): State<Int> {
    val fps = remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        var frames = 0; var t0 = 0L
        while (true) {
            val t = withFrameNanosCompat()
            if (t0 == 0L) t0 = t
            frames++
            if (t - t0 >= 1_000_000_000L) { fps.intValue = frames; frames = 0; t0 = t }
        }
    }
    return fps
}

private suspend fun withFrameNanosCompat(): Long = androidx.compose.runtime.withFrameNanos { it }

@Composable
fun Monitor(store: Store) {
    val s by rememberSnap(1000L)
    val fps by rememberOwnFps()
    val meter = remember { CpuMeter() }
    val cpu by produceState(0f) { while (true) { delay(1000); value = meter.pct() } }
    val warnC = store.profile("_global").warnC
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Monitor", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        val x = s
        if (x == null) { CircularProgressIndicator(color = Neon); return@Column }
        if (x.batTempC >= warnC || x.thermal >= 3) Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, null, tint = Color(0xFFFF5252))
                Text("  Perangkat panas. Turunkan grafik atau istirahat.", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
            }
        }
        Glass {
            Text("RAM", color = Dim, fontSize = 12.sp)
            Text("${x.ramUsedMb} / ${x.ramTotalMb} MB dipakai", color = Color.White, fontWeight = FontWeight.Bold)
            LinearProgressIndicator({ x.ramUsedMb.toFloat() / x.ramTotalMb.coerceAtLeast(1) }, Modifier.fillMaxWidth().padding(top = 6.dp), color = Neon)
            if (x.lowMem) Text("Sistem melaporkan memori rendah", color = Color(0xFFFF5252), fontSize = 12.sp)
        }
        Glass {
            Text("Suhu", color = Dim, fontSize = 12.sp)
            Text("Baterai: %.1f°C".format(x.batTempC), color = Color.White, fontWeight = FontWeight.Bold)
            Text("Status termal sistem: ${Sys.thermalLabel(x.thermal)}", color = Color.White, fontSize = 13.sp)
            Text(
                if (x.headroom.isNaN()) "Thermal headroom: tidak didukung perangkat ini"
                else "Thermal headroom (10 dtk ke depan): %.2f (1.0 = batas throttling)".format(x.headroom),
                color = Color.White, fontSize = 13.sp
            )
        }
        Glass {
            Text("CPU", color = Dim, fontSize = 12.sp)
            Text("Proses aplikasi ini: %.1f%%".format(cpu), color = Color.White, fontWeight = FontWeight.Bold)
        }
        Glass {
            Text("Refresh rate layar", color = Dim, fontSize = 12.sp)
            Text("$fps Hz", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Baterai", "${x.batPct}%", if (x.charging) "Mengisi" else "Tidak mengisi", Modifier.weight(1f))
            Stat("Jaringan", x.net, "", Modifier.weight(1f))
        }
    }
}

@Composable
fun SettingsScreen() {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(c) }
    val dndOk = remember(tick) { c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Glass {
            Text("Izin (diberikan manual oleh pengguna)", color = Neon, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Floating overlay: ${if (overlayOk) "aktif" else "belum"}", Modifier.weight(1f), color = Color.White)
                Button({ c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))) }) { Text("Atur") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Jangan Ganggu: ${if (dndOk) "aktif" else "belum"}", Modifier.weight(1f), color = Color.White)
                Button({ c.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) { Text("Atur") }
            }
        }
        Glass {
            Text("Tentang", color = Neon, fontWeight = FontWeight.Bold)
            Text("VANX GAME BOOSTER v1.2.0\nDeveloper: VANZ", color = Color.White)
            Text("Tanpa root, tanpa exploit. Semua data dari API Android resmi.", color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
fun LaunchScreen(a: AppItem, store: Store, onClose: () -> Unit) {
    val c = LocalContext.current
    val p = remember { store.profile(a.pkg) }
    val fast = store.minAnim
    val tips = remember { gfxTips(a.pkg, p.gfx) }
    var lines by remember { mutableStateOf(listOf<String>()) }
    var err by remember { mutableStateOf<String?>(null) }
    var target by remember { mutableFloatStateOf(0f) }
    var stage by remember { mutableStateOf("MENGANALISIS PERANGKAT") }
    val prog by animateFloatAsState(target, if (fast) snap() else tween(450), label = "prog")
    val inf = rememberInfiniteTransition(label = "inf")
    val spinA by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "spin")
    val pulseA by inf.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val scanA by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "scan")
    val spin = if (fast) 0f else spinA
    val pulse = if (fast) 1f else pulseA
    BackHandler(onBack = onClose)
    LaunchedEffect(a.pkg) {
        val r = runBoost(c, p.effective(), a.pkg, store)
        stage = "MENGOPTIMALKAN"
        r.lines.forEachIndexed { i, l ->
            lines = lines + l
            target = 0.15f + 0.7f * (i + 1) / r.lines.size
            if (!fast) delay(240)
        }
        stage = "SIAP BERMAIN"; target = 1f
        delay(if (fast) 200 else 800)
        val intent = c.packageManager.getLaunchIntentForPackage(a.pkg)
        if (intent == null) { err = "Game tidak bisa dibuka: tidak ada activity peluncur."; return@LaunchedEffect }
        try {
            GameSessionService.start(c, a.pkg, a.label)
            c.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onClose()
        } catch (e: Exception) {
            GameSessionService.stop(c); err = "Gagal membuka game: ${e.message}"
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF2A0610), Bg, Color(0xFF05161A)))).pointerInput(Unit) {}) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val y = scanA * h; val band = 60.dp.toPx()
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, Neon.copy(alpha = 0.28f), Color.Transparent), startY = y - band, endY = y + band),
                topLeft = Offset(0f, y - band), size = Size(w, band * 2)
            )
            val m = 20.dp.toPx(); val len = 36.dp.toPx(); val sw = 3.dp.toPx()
            fun corner(x: Float, yy: Float, dx: Float, dy: Float) {
                drawLine(Neon, Offset(x, yy), Offset(x + dx * len, yy), sw)
                drawLine(Neon, Offset(x, yy), Offset(x, yy + dy * len), sw)
            }
            corner(m, m, 1f, 1f); corner(w - m, m, -1f, 1f); corner(m, h - m, 1f, -1f); corner(w - m, h - m, -1f, -1f)
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(210.dp), Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(6.dp)) {
                    rotate(spin) { drawArc(brush = RingBrush, startAngle = 0f, sweepAngle = 100f, useCenter = false, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)) }
                    rotate(-spin * 0.6f) {
                        drawArc(
                            color = Purple.copy(alpha = 0.7f), startAngle = 180f, sweepAngle = 60f, useCenter = false,
                            topLeft = Offset(14.dp.toPx(), 14.dp.toPx()), size = Size(size.width - 28.dp.toPx(), size.height - 28.dp.toPx()),
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                    drawCircle(Neon.copy(alpha = 0.12f), radius = size.minDimension / 2 * 0.72f * pulse)
                }
                Box(Modifier.scale(pulse)) { AppIcon(a.pkg, 96.dp) }
            }
            Spacer(Modifier.height(20.dp))
            Text(a.label.uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, textAlign = TextAlign.Center)
            Text(stage, color = Neon, fontSize = 12.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(16.dp))
            Text("${(prog * 100).toInt()}%", color = Purple, fontSize = 40.sp, fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                val on = (prog * 24).toInt()
                repeat(24) { i ->
                    Box(Modifier.weight(1f).height(10.dp).background(if (i < on) Neon else Color(0x22FFFFFF), CutCornerShape(topStart = 3.dp, bottomEnd = 3.dp)))
                }
            }
            lines.takeLast(7).forEach {
                Text("> $it", color = Color(0xFFB8F7FF), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp))
            }
            if (tips.isNotEmpty()) Glass(Modifier.padding(top = 14.dp)) {
                Text("SETEL DI DALAM GAME (${p.gfx})", color = Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                tips.forEach { Text("• $it", color = Color.White, fontSize = 12.sp) }
            }
            err?.let {
                Text(it, color = Color(0xFFFF5252), modifier = Modifier.padding(top = 12.dp))
                Button(onClose, Modifier.padding(top = 8.dp)) { Text("Kembali") }
            }
        }
    }
}

object AppCache {
    @Volatile var apps: List<AppItem>? = null
    val icons = java.util.concurrent.ConcurrentHashMap<String, ImageBitmap>()
    suspend fun get(c: android.content.Context): List<AppItem> {
        apps?.let { return it }
        val r = withContext(Dispatchers.IO) { scanApps(c.applicationContext) }
        apps = r
        return r
    }
}
